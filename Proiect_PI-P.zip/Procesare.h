#ifndef PROCESARE_H_
#define PROCESARE_H_
#include "ByteVect.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

Byte* Gray(Byte*, int);

#endif